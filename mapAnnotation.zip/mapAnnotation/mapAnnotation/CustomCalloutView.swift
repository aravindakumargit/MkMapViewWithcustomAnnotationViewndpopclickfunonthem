//
//  CustomCalloutView.swift
//  mapAnnotation
//
//  Created by cricket21 on 24/05/17.
//  Copyright © 2017 cricket21. All rights reserved.
//

import UIKit

class CustomCalloutView: UIView {

    @IBOutlet var starbucksImage: UIImageView!
    @IBOutlet var starbucksPhone: UILabel!
    @IBOutlet var starbucksAddress: UILabel!
    @IBOutlet var starbucksName: UILabel!
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
