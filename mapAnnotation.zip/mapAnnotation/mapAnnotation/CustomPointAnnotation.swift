//
//  CustomPointAnnotation.swift
//  mapAnnotation
//
//  Created by cricket21 on 23/05/17.
//  Copyright © 2017 cricket21. All rights reserved.
//

import UIKit
import MapKit
class CustomPointAnnotation: NSObject,MKAnnotation {
    var coordinate: CLLocationCoordinate2D
    var phone: String!
    var name: String!
    var address: String!
    var image: UIImage!
    
    init(coordinate: CLLocationCoordinate2D) {
        self.coordinate = coordinate
    }

}
