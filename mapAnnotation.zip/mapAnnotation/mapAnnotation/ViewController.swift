//
//  ViewController.swift
//  mapAnnotation
//
//  Created by cricket21 on 23/05/17.
//  Copyright © 2017 cricket21. All rights reserved.
//

import UIKit
import MapKit
class ViewController: UIViewController,MKMapViewDelegate {
    @IBOutlet var BackgroundView: UIView!
    var coordinates: [[Double]]!
    var names:[String]!
    var addresses:[String]!
    var phones:[String]!
    @IBOutlet var MapView: MKMapView!
    @IBOutlet var HeaderLbl: UILabel!
    @IBOutlet var AddressLbl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        BackgroundView.isHidden=true
        BackgroundView.backgroundColor = UIColor.black.withAlphaComponent(0.75)
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:)))
        BackgroundView.addGestureRecognizer(tap)
        BackgroundView.isUserInteractionEnabled = true
        coordinates = [[48.85672,2.35501],[48.85196,2.33944],[48.85376,2.33953]]// Latitude,Longitude
        names = ["Coffee Shop · Rue de Rivoli","Cafe · Boulevard Saint-Germain","Coffee Shop · Rue Saint-André des Arts"]
        addresses = ["46 Rue de Rivoli, 75004 Paris, France","91 Boulevard Saint-Germain, 75006 Paris, France","62 Rue Saint-André des Arts, 75006 Paris, France"]
        phones = ["+33144789478","+33146345268","+33146340672"]
        self.MapView.delegate = self
        // 2
        for i in 0...2
        {
            let coordinate = coordinates[i]
            let point = CustomPointAnnotation(coordinate: CLLocationCoordinate2D(latitude: coordinate[0] , longitude: coordinate[1] ))
            //point.image = UIImage(named: "starbucks-\(i+1).jpg")
            point.image = UIImage(named: "starbucks.jpg")
            point.name = names[i]
            point.address = addresses[i]
            point.phone = phones[i]
            self.MapView.addAnnotation(point)
        }
        // 3
        let region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 48.856614, longitude: 2.3522219000000177), span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1))
        self.MapView.setRegion(region, animated: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        if annotation is MKUserLocation
        {
            return nil
        }
        var annotationView = self.MapView.dequeueReusableAnnotationView(withIdentifier: "Pin")
        
        if annotationView == nil{
            annotationView = AnnotationView(annotation: annotation, reuseIdentifier: "Pin")
            let popupImg = UIImageView(frame: CGRect(x:0, y: 0, width: 60, height: 60))
            popupImg.image = UIImage(named:"")//set popup img here
            annotationView?.backgroundColor = UIColor.blue
            annotationView?.addSubview(popupImg)
            
           
            annotationView?.frame=CGRect(x:0, y: 0, width: 60, height:60 )
            let ratingLbl = UILabel(frame: CGRect(x:1, y: 3, width: 20, height: 10))
            ratingLbl.textColor = UIColor.white
            ratingLbl.text = "1.5"
            ratingLbl.font = ratingLbl.font.withSize(12)
            popupImg.addSubview(ratingLbl)
        
            
            
             let ratingImg = UIImageView(frame: CGRect(x:ratingLbl.frame.origin.x+ratingLbl.frame.size.width, y: 3, width: 20, height: 20))
            ratingImg.image = UIImage(named:"star.png")
            popupImg.addSubview(ratingImg)
            
            let OffersLbl = UILabel(frame: CGRect(x:1, y:ratingImg.frame.origin.y+ratingImg.frame.size.width+5, width: 50, height: 10))
            OffersLbl.textColor = UIColor.white
            OffersLbl.text = "5 offers"
            OffersLbl.font = ratingLbl.font.withSize(12)
            popupImg.addSubview(OffersLbl)


        }else{
            annotationView?.annotation = annotation
           
        }
        
        return annotationView
    }
    

    func mapView(_ mapView: MKMapView,
                 didSelect view: MKAnnotationView)
    {
        if view.annotation is MKUserLocation
        {
        return
        }
        let starbucksAnnotation = view.annotation as! CustomPointAnnotation
        mapView.setCenter((view.annotation?.coordinate)!, animated: true)
        BackgroundView.isHidden=false
        HeaderLbl.text=starbucksAnnotation.name
        AddressLbl.text=starbucksAnnotation.address
    }
    func callPhoneNumber(sender: UIButton)
    {
        let v = sender.superview as! CustomCalloutView
        if let url = URL(string: "telprompt://\(v.starbucksPhone.text!)"), UIApplication.shared.canOpenURL(url)
        {
            UIApplication.shared.openURL(url)
        }
    }
    func mapView(_ mapView: MKMapView, didDeselect view: MKAnnotationView) {
        if view.isKind(of: AnnotationView.self)
        {
            for subview in view.subviews
            {
                subview.removeFromSuperview()
            }
        }
    }
func baseload(){
    BackgroundView.backgroundColor = UIColor.black.withAlphaComponent(0.75)
}
    
    

@IBAction func DirectionAction(_ sender: Any) {
        UIApplication.shared.openURL(NSURL(string:
            "comgooglemaps://?saddr=&daddr=\("13.0827"),\("80.2707")&directionsmode=driving")! as URL)
}
    
    func handleTap(_ sender: UITapGestureRecognizer) {
        BackgroundView.isHidden=true
        self.MapView.reloadInputViews()
        
        self.MapView.delegate = self
        // 2
        for i in 0...2
        {
            let coordinate = coordinates[i]
            let point = CustomPointAnnotation(coordinate: CLLocationCoordinate2D(latitude: coordinate[0] , longitude: coordinate[1] ))
            //point.image = UIImage(named: "starbucks-\(i+1).jpg")
            point.image = UIImage(named: "starbucks.jpg")
            point.name = names[i]
            point.address = addresses[i]
            point.phone = phones[i]
            self.MapView.addAnnotation(point)
        }
        // 3
        let region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 48.856614, longitude: 2.3522219000000177), span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1))
        self.MapView.setRegion(region, animated: true)
    }
    
    func MapStuff(){
        
    }
   
    
    
    
    
}

